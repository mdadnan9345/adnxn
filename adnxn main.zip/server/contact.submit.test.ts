import { describe, expect, it, vi } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

const mocks = vi.hoisted(() => ({
  insertSubmission: vi.fn().mockResolvedValue(undefined),
  sendContactEmail: vi.fn().mockResolvedValue(true),
}));

vi.mock("./db", async () => {
  const actual = await vi.importActual<typeof import("./db")>("./db");
  return { ...actual, createContactSubmission: mocks.insertSubmission };
});

vi.mock("./email", () => ({ sendContactEmail: mocks.sendContactEmail }));

describe("contact.submit", () => {
  it("stores the full submission and sends an email notification", async () => {
    const ctx: TrpcContext = {
      user: null,
      req: {} as TrpcContext["req"],
      res: {} as TrpcContext["res"],
    };
    const caller = appRouter.createCaller(ctx);
    const payload = {
      name: "Aisha Khan",
      email: "aisha@example.com",
      subject: "Website project",
      message: "I would like to discuss a new website for my business.",
    };

    const result = await caller.contact.submit(payload);

    expect(result).toEqual({ success: true, emailSent: true });
    expect(mocks.insertSubmission).toHaveBeenCalledWith(payload);
    expect(mocks.sendContactEmail).toHaveBeenCalledWith(payload);
  });
});
