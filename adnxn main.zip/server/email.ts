export type ContactEmailPayload = {
  name: string;
  email: string;
  subject: string;
  message: string;
};

const inbox = "mdadnan018863@gmail.com";
const formSubmitEndpoint = `https://formsubmit.co/ajax/${inbox}`;

export async function sendContactEmail(payload: ContactEmailPayload) {
  try {
    const response = await fetch(formSubmitEndpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify({
        name: payload.name,
        email: payload.email,
        subject: payload.subject,
        message: payload.message,
        _subject: `[Adnxn] New Start a project enquiry: ${payload.subject}`,
        _template: "table",
      }),
    });

    if (!response.ok) {
      console.warn(`[FormSubmit] Forwarding failed with HTTP ${response.status}`);
      return false;
    }

    const result = (await response.json()) as { success?: boolean };
    if (result.success !== true) {
      console.warn("[FormSubmit] Forwarding did not return success.");
      return false;
    }

    return true;
  } catch (error) {
    console.warn("[FormSubmit] Forwarding failed; contact was stored but email was not sent.", error);
    return false;
  }
}
