import { afterEach, describe, expect, it, vi } from "vitest";
import { sendContactEmail } from "./email";

afterEach(() => {
  vi.unstubAllGlobals();
});

describe("FormSubmit contact forwarding", () => {
  it("forwards the complete Start a project payload to the private recipient endpoint", async () => {
    const fetchMock = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ success: true }), {
        status: 200,
        headers: { "Content-Type": "application/json" },
      }),
    );
    vi.stubGlobal("fetch", fetchMock);

    const payload = {
      name: "Aisha Khan",
      email: "aisha@example.com",
      subject: "Website project",
      message: "I would like to discuss a new website for my business.",
    };

    await expect(sendContactEmail(payload)).resolves.toBe(true);

    expect(fetchMock).toHaveBeenCalledWith(
      "https://formsubmit.co/ajax/mdadnan018863@gmail.com",
      expect.objectContaining({
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
        },
        body: JSON.stringify({
          ...payload,
          _subject: "[Adnxn] New Start a project enquiry: Website project",
          _template: "table",
        }),
      }),
    );
  });
});
