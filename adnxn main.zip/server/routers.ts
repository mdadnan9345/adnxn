import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { createContactSubmission } from "./db";
import { sendContactEmail } from "./email";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";

const contactSchema = z.object({
  name: z.string().trim().min(2).max(160),
  email: z.string().trim().email().max(320),
  subject: z.string().trim().min(2).max(240),
  message: z.string().trim().min(10).max(5000),
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  contact: router({
    submit: publicProcedure.input(contactSchema).mutation(async ({ input }) => {
      await createContactSubmission(input);
      const emailSent = await sendContactEmail(input);
      return { success: true, emailSent } as const;
    }),
  }),
});

export type AppRouter = typeof appRouter;
