import { FormEvent, useState } from "react";
import { toast } from "sonner";
import {
  ArrowUpRight,
  BarChart3,
  Check,
  ChevronDown,
  Code2,
  Globe2,
  Instagram,
  Layers3,
  Linkedin,
  Menu,
  MessageSquareText,
  Search,
  Send,
  ShieldCheck,
  Smartphone,
  Sparkles,
  Wrench,
  X,
} from "lucide-react";

const services = [
  { icon: Globe2, number: "01", title: "Web Development", description: "High-performance websites designed around your business goals and built to make a clear first impression." },
  { icon: Smartphone, number: "02", title: "App Development", description: "Focused web applications that simplify operations, serve customers, and create room to grow." },
  { icon: Search, number: "03", title: "SEO", description: "Technical and content foundations that help the right people discover your business over time." },
  { icon: BarChart3, number: "04", title: "Digital Marketing", description: "Clear campaigns and measurement designed to reach the right audience with less wasted effort." },
  { icon: Layers3, number: "05", title: "E-commerce", description: "Commerce experiences that improve product discovery, trust, and the path to purchase." },
  { icon: Wrench, number: "06", title: "Maintenance", description: "Ongoing updates, monitoring, and support that keep your digital presence dependable." },
];

const audiences = [
  ["01", "Startups", "Launch with a credible digital foundation that can evolve as your idea becomes a business."],
  ["02", "SMBs", "Modernise your presence, generate qualified enquiries, and remove avoidable manual work."],
  ["03", "Local Businesses", "Make it easier for nearby customers to find you, trust you, and take the next step."],
  ["04", "E-commerce", "Create a clearer product journey with stronger performance and conversion fundamentals."],
  ["05", "Professional Services", "Build a measured, credible experience that supports high-trust client decisions."],
];

const process = [
  ["01", "Understand", "We learn your goals, users, and constraints before recommending a direction."],
  ["02", "Plan", "We define priorities, scope, and a practical architecture for the work ahead."],
  ["03", "Build", "We design and develop in reviewable increments, keeping progress visible."],
  ["04", "Launch", "We ship carefully, measure the experience, and hand over with clarity."],
  ["05", "Improve", "We keep learning from real use and support the next stage of growth."],
];

const differentiators = [
  [MessageSquareText, "One accountable partner", "The technical and growth work stays connected through one focused team."],
  [BarChart3, "Outcome-driven", "We design around the result your business needs, not a checklist of deliverables."],
  [Code2, "Modular architecture", "The work is structured to be straightforward to extend as your needs grow."],
  [ShieldCheck, "Secure by default", "Security, accessibility, and performance are considered from the start."],
];

const faqs = [
  ["What does Adnxn do?", "Adnxn builds websites and web applications, and supports growth through SEO, digital marketing, e-commerce, and ongoing maintenance."],
  ["How do we get started?", "Start with a conversation about your goals, audience, and current constraints. We will help shape a clear scope and practical next step."],
  ["Do you guarantee rankings or advertising returns?", "No. SEO and advertising outcomes depend on competition, market conditions, budget, and other external factors. We focus on disciplined execution and measurable learning."],
  ["Which regions does Adnxn serve?", "Adnxn primarily works with businesses in India. Additional regions can be discussed when you get in touch."],
  ["Do you offer support after launch?", "Yes. Maintenance and ongoing improvement can be scoped around what your business needs after launch."],
];

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [form, setForm] = useState({ name: "", email: "", subject: "", message: "" });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    setIsSubmitting(true);
    try {
      const response = await fetch("https://formsubmit.co/ajax/mdadnan018863@gmail.com", {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json" },
        body: JSON.stringify({
          name: form.name,
          email: form.email,
          subject: form.subject,
          message: form.message,
          _subject: `[Adnxn] New Start a project enquiry: ${form.subject}`,
          _template: "table",
        }),
      });
      const result = response.ok ? ((await response.json()) as { success?: boolean }) : { success: false };
      if (result.success) {
        setForm({ name: "", email: "", subject: "", message: "" });
        toast.success("Message sent. We will be in touch soon.");
      } else {
        toast.error("Something went wrong. Please try again or email us directly.");
      }
    } catch {
      toast.error("Something went wrong. Please try again or email us directly.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const closeMenu = () => setMenuOpen(false);

  return (
    <div className="min-h-screen bg-[#fdfdfb] text-[#111111] selection:bg-[#ef2b2d] selection:text-white">
      <header className="site-header">
        <a href="#top" className="brand" aria-label="Adnxn home"><img className="brand-logo" src="/adnex-logo.png" alt="Adnxn" /></a>
        <nav className={`desktop-nav ${menuOpen ? "is-open" : ""}`} aria-label="Primary navigation">
          {[["Services", "#services"], ["Who We Help", "#audiences"], ["How We Work", "#process"], ["FAQ", "#faq"], ["Contact", "#contact"]].map(([label, href]) => <a key={href} href={href} onClick={closeMenu}>{label}</a>)}
        </nav>
        <a className="header-cta" href="#contact">Get a proposal <ArrowUpRight size={16} /></a>
        <button className="menu-toggle" onClick={() => setMenuOpen((value) => !value)} aria-label={menuOpen ? "Close menu" : "Open menu"}>{menuOpen ? <X /> : <Menu />}</button>
      </header>

      <main id="top">
        <section className="hero section-grid" aria-labelledby="hero-title">
          <div className="hero-copy reveal">
            <p className="eyebrow"><span className="red-square" /> Digital systems &amp; growth</p>
            <h1 id="hero-title">Build better.<br /><em>Move forward.</em></h1>
            <p className="hero-subtitle">Adnxn designs and builds the digital systems that help businesses communicate clearly, operate better, and grow with confidence.</p>
            <div className="hero-actions"><a className="button button-red" href="#contact">Get a proposal <ArrowUpRight size={18} /></a><a className="button button-outline" href="#services">Explore services <ArrowUpRight size={18} /></a></div>
          </div>
          <div className="hero-graphic reveal-delay" aria-hidden="true"><div className="graphic-frame"><div className="graphic-label">ADNEX / 2026</div><div className="graphic-cross cross-one" /><div className="graphic-cross cross-two" /><div className="graphic-square" /><div className="graphic-line line-one" /><div className="graphic-line line-two" /><span className="graphic-caption">clarity<br />in motion</span></div></div>
          <div className="hero-meta"><span>01 — 08</span><span>India / Remote</span><span className="scroll-cue">Scroll to explore <span>↓</span></span></div>
        </section>

        <section id="services" className="content-section section-grid" aria-labelledby="services-title">
          <div className="section-intro"><p className="section-index">01 / Services</p><h2 id="services-title">Everything you need<br /><em>to move online.</em></h2></div>
          <div className="section-description"><p>From your first digital presence to the systems that support your next stage, Adnxn brings focused design, development, and growth thinking together.</p></div>
          <div className="service-grid full-span">{services.map(({ icon: Icon, number, title, description }) => <article className="service-card" key={title}><div className="card-top"><span>{number}</span><Icon size={24} strokeWidth={1.5} /></div><h3>{title}</h3><p>{description}</p><a href="#contact" aria-label={`Talk to Adnxn about ${title}`}>Discuss this <ArrowUpRight size={16} /></a></article>)}</div>
        </section>

        <section id="audiences" className="content-section dark-section section-grid" aria-labelledby="audiences-title">
          <div className="section-intro"><p className="section-index">02 / Who we help</p><h2 id="audiences-title">Built for where<br /><em>you are now.</em></h2></div>
          <div className="section-description"><p>Different businesses need different starting points. The work stays grounded in your stage, your audience, and the decision you need your website to support.</p></div>
          <div className="audience-list full-span">{audiences.map(([number, title, description]) => <article className="audience-row" key={title}><span className="row-number">{number}</span><h3>{title}</h3><p>{description}</p><ArrowUpRight className="row-arrow" size={22} /></article>)}</div>
        </section>

        <section id="process" className="content-section section-grid" aria-labelledby="process-title">
          <div className="section-intro"><p className="section-index">03 / How we work</p><h2 id="process-title">A clear path from<br /><em>idea to impact.</em></h2></div>
          <div className="section-description"><p>No unnecessary layers. Just a reviewable process that keeps the work aligned, visible, and moving forward.</p></div>
          <div className="process-grid full-span">{process.map(([number, title, description], index) => <article className="process-step" key={title}><span className="step-number">{number}</span><div className="step-rule" /><h3>{title}</h3><p>{description}</p>{index < process.length - 1 && <span className="step-connector">→</span>}</article>)}</div>
        </section>

        <section className="content-section accent-section section-grid" aria-labelledby="why-title">
          <div className="section-intro"><p className="section-index">04 / Why Adnxn</p><h2 id="why-title">Structure that<br /><em>creates momentum.</em></h2></div>
          <div className="section-description"><p>Good digital work should make the next decision easier. We combine a precise process with practical systems that can keep earning their place.</p></div>
          <div className="difference-grid full-span">{differentiators.map(([Icon, title, description]) => <article className="difference-card" key={title as string}><Icon size={25} strokeWidth={1.5} /><h3>{title as string}</h3><p>{description as string}</p></article>)}</div>
        </section>

        <section id="faq" className="content-section faq-section section-grid" aria-labelledby="faq-title">
          <div className="section-intro"><p className="section-index">05 / FAQ</p><h2 id="faq-title">A few useful<br /><em>answers.</em></h2></div>
          <div className="faq-list">{faqs.map(([question, answer], index) => <div className={`faq-item ${openFaq === index ? "open" : ""}`} key={question}><button onClick={() => setOpenFaq(openFaq === index ? null : index)} aria-expanded={openFaq === index}><span>{question}</span><ChevronDown size={20} /></button>{openFaq === index && <p>{answer}</p>}</div>)}</div>
        </section>

        <section id="contact" className="contact-section section-grid" aria-labelledby="contact-title">
          <div className="contact-intro"><p className="section-index">06 / Start a project</p><h2 id="contact-title">Have something<br /><em>in mind?</em></h2><p>Tell us what you are building, improving, or trying to solve. We will get back to you with a thoughtful next step.</p><a className="contact-email" href="mailto:support@adnxn.com">support@adnxn.com <ArrowUpRight size={18} /></a></div>
          <form id="contact-form" className="contact-form" onSubmit={submit}><div className="form-row"><label>Name<input required value={form.name} onChange={(event) => setForm({ ...form, name: event.target.value })} placeholder="Your name" /></label><label>Email<input required type="email" value={form.email} onChange={(event) => setForm({ ...form, email: event.target.value })} placeholder="you@company.com" /></label></div><label>Subject<input required value={form.subject} onChange={(event) => setForm({ ...form, subject: event.target.value })} placeholder="What can we help with?" /></label><label>Message<textarea required rows={5} value={form.message} onChange={(event) => setForm({ ...form, message: event.target.value })} placeholder="A little about your project..." /></label><button className="button button-red submit-button" type="submit" disabled={isSubmitting}>{isSubmitting ? "Sending..." : "Send message"} {isSubmitting ? <Sparkles size={18} /> : <Send size={18} />}</button></form>
        </section>
      </main>

      <footer className="site-footer"><a href="#top" className="brand"><img className="brand-logo" src="/adnex-logo.png" alt="Adnxn" /></a><p>Digital systems that move business forward.</p><div className="footer-links"><a href="#services">Services</a><a href="#process">Process</a><a href="#contact">Contact</a></div><div className="social-links"><a href="#contact" aria-label="Ask Adnxn about social channels" title="Ask Adnxn about social channels"><Linkedin size={18} /></a><a href="https://www.instagram.com/adnxn_cx?igsi=NnFnZ2t2a2hsaG5i" target="_blank" rel="noreferrer" aria-label="Adnxn on Instagram" title="Adnxn on Instagram"><Instagram size={18} /></a></div><span className="copyright">© 2026 Adnxn. All rights reserved.</span></footer>
    </div>
  );
}
